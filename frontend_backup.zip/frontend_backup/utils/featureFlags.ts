// Turn mock auth ON while you build UX. Flip to false to go back to real Supabase.
export const MOCK_AUTH = false;
